/* BWM service worker — offline shell + Mapbox tile cache.
 *
 * Strategies:
 *  - Mapbox tiles/styles/fonts/sprites: cache-first, stale-while-revalidate
 *  - HTML navigations: network-first, fall back to cached shell
 *  - Other GETs: pass-through
 *
 * Registration is guarded to skip iframes / preview hosts (see main.tsx).
 */

const CACHE_VERSION = "bwm-v1";
const TILE_CACHE = `${CACHE_VERSION}-mapbox`;
const SHELL_CACHE = `${CACHE_VERSION}-shell`;

self.addEventListener("install", (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => !k.startsWith(CACHE_VERSION))
          .map((k) => caches.delete(k)),
      );
      await self.clients.claim();
    })(),
  );
});

const MAPBOX_HOSTS = ["api.mapbox.com", "events.mapbox.com", "tiles.mapbox.com"];

function isMapboxRequest(url) {
  return MAPBOX_HOSTS.some((h) => url.hostname.endsWith(h));
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Mapbox: cache-first with background refresh.
  if (isMapboxRequest(url)) {
    // Skip telemetry/event pings — never cache them.
    if (url.hostname.includes("events.mapbox.com")) return;
    event.respondWith(
      (async () => {
        const cache = await caches.open(TILE_CACHE);
        const cached = await cache.match(req);
        const network = fetch(req)
          .then((res) => {
            if (res && res.status === 200) cache.put(req, res.clone());
            return res;
          })
          .catch(() => null);
        return cached || (await network) || new Response("offline", { status: 503 });
      })(),
    );
    return;
  }

  // HTML navigations: network-first with cached shell fallback.
  if (req.mode === "navigate") {
    event.respondWith(
      (async () => {
        try {
          const res = await fetch(req);
          const cache = await caches.open(SHELL_CACHE);
          cache.put("/", res.clone()).catch(() => {});
          return res;
        } catch {
          const cache = await caches.open(SHELL_CACHE);
          const fallback = await cache.match("/");
          return (
            fallback ||
            new Response(
              "<h1>Offline</h1><p>You are offline and no cached page is available.</p>",
              { status: 503, headers: { "Content-Type": "text/html" } },
            )
          );
        }
      })(),
    );
  }
});
