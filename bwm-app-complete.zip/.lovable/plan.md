# BWM Marketplace — Phased Implementation Plan

This is a large, multi-week scope. I'll deliver it in 4 sequential phases, shipping a working slice at the end of each phase so you can review before the next one starts. Demo mode (already built) stays the default driver, with real Supabase tables behind it so the same UI works once API keys are added.

## Phase 1 — Car Pilot (Operator) end-to-end

**Onboarding & verification**
- Multi-step signup wizard: account → OTP → personal info → documents → vehicle/equipment → certifications → payout method → review.
- Document component with upload, preview, expiry, doc number, issuing authority, status (Pending/Approved/Rejected/Expired), reject reason, re-upload.
- Profile completion % + verification checklist on home.
- Gate bidding behind `verification_status = approved`.

**Pilot dashboard**
- Tabs: Available / My Bids / Accepted / In Progress / Awaiting Approval / Completed / Cancelled / Disputed.
- Job detail: route map, load, requirements, dispatcher card, documents, Submit Bid.
- Bid sheet: amount, proposal, ETA, equipment, supporting docs.
- Earnings page: total / pending / available / payouts / per-job breakdown / invoices.
- Live trip actions: Start → Arrived pickup → Pickup complete → In transit → Report issue → Arrived → Mark complete + proof upload.

**Schema added**
`pilot_profiles`, `pilot_documents`, `pilot_vehicles`, `pilot_certifications`, `pilot_payout_methods`, `bids`, `pilot_earnings`. RLS scoped to `auth.uid()`; admin policy via `has_role`.

## Phase 2 — Fleet Dispatcher end-to-end

**Onboarding & verification**
- Wizard: account → OTP → business info (trade license, registration, tax ID) → documents → payment method → review.
- Drafts allowed pre-approval; publishing gated on approval + valid payment method.

**Job posting wizard**
- Steps: basics → load/permits → pilot requirements → budget → review.
- Status machine: Draft → Pending Admin Review → Approved/Live → Open for Bids → Pilot Selected → Awaiting Payment → Escrow Funded → In Progress → Completion Submitted → Awaiting Approval → Completed/Paid → Disputed → Cancelled/Refunded.

**Dispatcher dashboard**
- Tabs mirroring job statuses, bid comparison view (filter by price/rating/distance/equipment), pilot profile drawer, in-job chat & call buttons.
- Escrow payment screen (Stripe Connect simulated via existing `PaymentsDemo`, real keys pluggable later).
- Completion approval screen: proof gallery, route timeline, Approve / Reject → Open Dispute.
- Spending, invoices, subscription ($499 / $999), commission (3.4%) breakdown.

**Schema added**
`dispatcher_profiles`, `dispatcher_documents`, `dispatcher_payment_methods`, `jobs` (replaces ad-hoc loads), `job_documents`, `payments` (escrow ledger), `subscriptions`, `invoices`.

## Phase 3 — Admin console

- Overview KPIs wired to real tables (users, pending verifications, escrow balance, revenue, disputes).
- User management: search, filter by role/status, suspend/reactivate, full profile drawer with documents.
- Verification queues: Pilot + Dispatcher with Approve / Reject (reason) / Request more info / internal notes.
- Job review queue: approve/reject/request edits before going live.
- Payments: transactions, escrow ledger, manual release/refund, Stripe IDs (placeholder), commission report.
- Subscriptions: plan management, failed payments, manual adjust.
- Disputes: case detail with both-side evidence, chat history, route logs, decision actions (release pilot / refund dispatcher / split / escalate).
- Live map: all active trips, status, alerts.
- Settings: commission %, plan config, doc rules, templates.
- `audit_logs` for every admin action.

**Schema added**
`user_roles` + `app_role` enum + `has_role()` SECURITY DEFINER, `disputes`, `dispute_evidence`, `audit_logs`, `notifications`, `admin_settings`.

## Phase 4 — Frontend polish & cross-cutting

- Notification center (in-app) + email/SMS/push placeholders.
- Ratings & reviews after completion.
- Job / payment / dispute timeline components.
- Document expiry alerts, risk flags, CSV export.
- Empty / loading / error / success states standardized.
- Mobile bottom-nav vs web sidebar layout per role.
- Help/Support, FAQ, Terms, Privacy pages.
- QA pass on all 8 user journeys; final implementation report.

## Cross-phase technical notes

- **Backend**: Supabase tables per phase via migrations, RLS on every user-data table, `has_role()` for admin policies, `createServerFn` for any business logic (escrow release, dispute resolution, admin actions).
- **Stripe**: Architecture only (Connect for payouts, Checkout for escrow funding, webhooks scaffolded). Keys remain placeholders — clearly marked "Needs API configuration".
- **Maps**: Existing Mapbox setup reused; live GPS already on `trip_locations` Realtime.
- **Chat/Calls**: Existing Supabase Realtime chat reused; Twilio voice/SMS stubs already in place.
- **Demo mode**: Every new screen seeds realistic demo data when `demo` flag is on, so the whole flow is testable without real signups or payments.
- **Theme**: White + gold accent preserved; all new components use existing semantic tokens in `src/styles.css`.

## Deliverables per phase

Each phase ends with: migration applied, screens shipped, demo seed updated, short changelog. After Phase 4 you get the full implementation report (executive summary, role/dashboard improvements, payment & verification flow docs, schema diff, route list, test checklist, pending integrations, screenshot checklist).

## Approval needed

Reply **"start phase 1"** to kick off Car Pilot. If you want to reorder, drop scope (e.g. skip subscriptions), or change priorities (e.g. Admin first), tell me now and I'll revise before any code lands.
