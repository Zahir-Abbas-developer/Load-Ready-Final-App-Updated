-- Enums
CREATE TYPE public.business_verification_status AS ENUM ('not_started','in_review','verified','rejected');
CREATE TYPE public.job_status AS ENUM ('draft','published','bidding','awarded','in_transit','completed','cancelled','disputed');
CREATE TYPE public.escrow_status AS ENUM ('initiated','charged','held','released','paid_out','refunded','failed');

-- Dispatcher profile (company)
CREATE TABLE public.dispatcher_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  company_name text,
  legal_name text,
  ein text,
  mc_number text,
  dot_number text,
  contact_name text,
  contact_phone text,
  billing_address text,
  city text,
  state text,
  postal_code text,
  country text,
  website text,
  verification_status business_verification_status NOT NULL DEFAULT 'not_started',
  rejection_reason text,
  completion_pct integer NOT NULL DEFAULT 0,
  rating numeric DEFAULT 0,
  stripe_customer_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.dispatcher_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dispatcher rw own profile" ON public.dispatcher_profiles
  FOR ALL USING (auth.uid() = user_id OR has_role(auth.uid(),'admin'))
  WITH CHECK (auth.uid() = user_id OR has_role(auth.uid(),'admin'));

CREATE POLICY "pilot read dispatcher basic" ON public.dispatcher_profiles
  FOR SELECT USING (has_role(auth.uid(),'pilot'));

CREATE TRIGGER dispatcher_profiles_updated BEFORE UPDATE ON public.dispatcher_profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Dispatcher documents
CREATE TABLE public.dispatcher_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  doc_type text NOT NULL,
  document_number text,
  issuing_authority text,
  expiry_date date,
  file_url text,
  status doc_status NOT NULL DEFAULT 'pending',
  rejection_reason text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.dispatcher_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dispatcher rw own docs" ON public.dispatcher_documents
  FOR ALL USING (auth.uid() = user_id OR has_role(auth.uid(),'admin'))
  WITH CHECK (auth.uid() = user_id OR has_role(auth.uid(),'admin'));

CREATE TRIGGER dispatcher_documents_updated BEFORE UPDATE ON public.dispatcher_documents
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Jobs
CREATE TABLE public.jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispatcher_id uuid NOT NULL,
  title text NOT NULL,
  description text,
  cargo_type text,
  dimensions text,
  weight text,
  pickup_location text NOT NULL,
  dropoff_location text NOT NULL,
  pickup_date timestamptz,
  dropoff_date timestamptz,
  distance_mi integer,
  budget numeric NOT NULL,
  requirements jsonb NOT NULL DEFAULT '{}'::jsonb,
  permits jsonb NOT NULL DEFAULT '[]'::jsonb,
  status job_status NOT NULL DEFAULT 'draft',
  awarded_pilot_id uuid,
  awarded_bid_id uuid,
  escrow_status escrow_status,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX jobs_dispatcher_idx ON public.jobs (dispatcher_id);
CREATE INDEX jobs_status_idx ON public.jobs (status);

ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dispatcher rw own jobs" ON public.jobs
  FOR ALL USING (auth.uid() = dispatcher_id OR has_role(auth.uid(),'admin'))
  WITH CHECK (auth.uid() = dispatcher_id OR has_role(auth.uid(),'admin'));

CREATE POLICY "pilot read open jobs" ON public.jobs
  FOR SELECT USING (
    status IN ('published','bidding')
    OR awarded_pilot_id = auth.uid()
    OR has_role(auth.uid(),'admin')
  );

CREATE TRIGGER jobs_updated BEFORE UPDATE ON public.jobs
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Escrow ledger
CREATE TABLE public.escrow_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL,
  dispatcher_id uuid NOT NULL,
  pilot_id uuid,
  amount numeric NOT NULL,
  platform_fee numeric NOT NULL DEFAULT 0,
  stripe_fee numeric NOT NULL DEFAULT 0,
  net_to_pilot numeric NOT NULL DEFAULT 0,
  status escrow_status NOT NULL DEFAULT 'initiated',
  stripe_payment_intent_id text,
  stripe_transfer_id text,
  stripe_payout_id text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX escrow_job_idx ON public.escrow_transactions (job_id);
CREATE INDEX escrow_dispatcher_idx ON public.escrow_transactions (dispatcher_id);
CREATE INDEX escrow_pilot_idx ON public.escrow_transactions (pilot_id);

ALTER TABLE public.escrow_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dispatcher read own escrow" ON public.escrow_transactions
  FOR SELECT USING (auth.uid() = dispatcher_id OR has_role(auth.uid(),'admin'));

CREATE POLICY "pilot read own escrow" ON public.escrow_transactions
  FOR SELECT USING (auth.uid() = pilot_id);

CREATE POLICY "dispatcher write own escrow" ON public.escrow_transactions
  FOR INSERT WITH CHECK (auth.uid() = dispatcher_id OR has_role(auth.uid(),'admin'));

CREATE POLICY "admin update escrow" ON public.escrow_transactions
  FOR UPDATE USING (has_role(auth.uid(),'admin') OR auth.uid() = dispatcher_id)
  WITH CHECK (has_role(auth.uid(),'admin') OR auth.uid() = dispatcher_id);

CREATE TRIGGER escrow_updated BEFORE UPDATE ON public.escrow_transactions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();