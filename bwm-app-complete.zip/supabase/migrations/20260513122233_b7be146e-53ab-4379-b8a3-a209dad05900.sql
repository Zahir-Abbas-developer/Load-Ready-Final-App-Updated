
create table public.trip_locations (
  id bigserial primary key,
  trip_id text not null,
  lng double precision not null,
  lat double precision not null,
  heading double precision,
  speed double precision,
  accuracy double precision,
  ts timestamptz not null default now()
);
create index trip_locations_trip_ts_idx on public.trip_locations (trip_id, ts desc);

create table public.trip_messages (
  id bigserial primary key,
  trip_id text not null,
  sender_role text not null,
  sender_name text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create index trip_messages_trip_created_idx on public.trip_messages (trip_id, created_at);

alter table public.trip_locations enable row level security;
alter table public.trip_messages enable row level security;

create policy "demo read locations" on public.trip_locations for select using (true);
create policy "demo write locations" on public.trip_locations for insert with check (true);
create policy "demo read messages" on public.trip_messages for select using (true);
create policy "demo write messages" on public.trip_messages for insert with check (true);

alter table public.trip_locations replica identity full;
alter table public.trip_messages replica identity full;
alter publication supabase_realtime add table public.trip_locations;
alter publication supabase_realtime add table public.trip_messages;
