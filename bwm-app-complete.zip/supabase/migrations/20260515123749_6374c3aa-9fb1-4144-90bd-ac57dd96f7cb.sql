-- Roles infrastructure (used across all phases)
CREATE TYPE public.app_role AS ENUM ('admin', 'pilot', 'dispatcher');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admins manage roles" ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Shared updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- Verification status enum
CREATE TYPE public.verification_status AS ENUM ('not_started','pending','approved','rejected','more_info');
CREATE TYPE public.doc_status AS ENUM ('pending','approved','rejected','expired');

-- Pilot profile
CREATE TABLE public.pilot_profiles (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  date_of_birth DATE,
  address TEXT, city TEXT, state TEXT, postal_code TEXT, country TEXT,
  emergency_contact TEXT,
  photo_url TEXT,
  years_experience INT,
  service_areas TEXT[],
  verification_status public.verification_status NOT NULL DEFAULT 'not_started',
  rejection_reason TEXT,
  rating NUMERIC(3,2) DEFAULT 0,
  completion_pct INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pilot_profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_pilot_profiles_updated BEFORE UPDATE ON public.pilot_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE POLICY "pilot read own profile" ON public.pilot_profiles FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'dispatcher'));
CREATE POLICY "pilot upsert own profile" ON public.pilot_profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pilot update own profile" ON public.pilot_profiles FOR UPDATE
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admin update verification" ON public.pilot_profiles FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Pilot documents
CREATE TABLE public.pilot_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL,
  file_url TEXT,
  document_number TEXT,
  issuing_authority TEXT,
  expiry_date DATE,
  status public.doc_status NOT NULL DEFAULT 'pending',
  rejection_reason TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pilot_documents ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_pilot_documents_updated BEFORE UPDATE ON public.pilot_documents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE POLICY "pilot read own docs" ON public.pilot_documents FOR SELECT USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "pilot write own docs" ON public.pilot_documents FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pilot update own docs" ON public.pilot_documents FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pilot delete own docs" ON public.pilot_documents FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "admin update docs" ON public.pilot_documents FOR UPDATE USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Pilot vehicles
CREATE TABLE public.pilot_vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vehicle_type TEXT, make TEXT, model TEXT, year INT,
  license_plate TEXT, vin TEXT,
  insurance_expiry DATE,
  equipment JSONB DEFAULT '{}'::jsonb,
  photos TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pilot_vehicles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_pilot_vehicles_updated BEFORE UPDATE ON public.pilot_vehicles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE POLICY "pilot rw own vehicles" ON public.pilot_vehicles FOR ALL USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));

-- Pilot certifications
CREATE TABLE public.pilot_certifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cert_type TEXT NOT NULL,
  cert_number TEXT,
  expiry_date DATE,
  file_url TEXT,
  status public.doc_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pilot_certifications ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_pilot_certs_updated BEFORE UPDATE ON public.pilot_certifications FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE POLICY "pilot rw own certs" ON public.pilot_certifications FOR ALL USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));

-- Pilot payout methods
CREATE TABLE public.pilot_payout_methods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  method_type TEXT NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_default BOOLEAN NOT NULL DEFAULT false,
  verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pilot_payout_methods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pilot rw own payouts" ON public.pilot_payout_methods FOR ALL USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));

-- Bids (jobs table comes in Phase 2; reference job by text id for now)
CREATE TYPE public.bid_status AS ENUM ('submitted','viewed','shortlisted','accepted','rejected','withdrawn','expired');
CREATE TABLE public.bids (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id TEXT NOT NULL,
  dispatcher_id UUID,
  pilot_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  message TEXT,
  eta_pickup TIMESTAMPTZ,
  eta_complete TIMESTAMPTZ,
  status public.bid_status NOT NULL DEFAULT 'submitted',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.bids ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_bids_updated BEFORE UPDATE ON public.bids FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_bids_job ON public.bids(job_id);
CREATE INDEX idx_bids_pilot ON public.bids(pilot_id);
CREATE POLICY "pilot read own bids" ON public.bids FOR SELECT USING (auth.uid() = pilot_id OR auth.uid() = dispatcher_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "pilot create own bid" ON public.bids FOR INSERT WITH CHECK (auth.uid() = pilot_id AND public.has_role(auth.uid(),'pilot'));
CREATE POLICY "pilot update own bid" ON public.bids FOR UPDATE USING (auth.uid() = pilot_id) WITH CHECK (auth.uid() = pilot_id);
CREATE POLICY "dispatcher update bid status" ON public.bids FOR UPDATE USING (auth.uid() = dispatcher_id) WITH CHECK (auth.uid() = dispatcher_id);

-- Earnings ledger
CREATE TYPE public.earning_status AS ENUM ('pending','available','paid','disputed','refunded');
CREATE TABLE public.pilot_earnings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pilot_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL,
  gross NUMERIC(12,2) NOT NULL,
  commission NUMERIC(12,2) NOT NULL DEFAULT 0,
  net NUMERIC(12,2) NOT NULL,
  status public.earning_status NOT NULL DEFAULT 'pending',
  payout_method_id UUID REFERENCES public.pilot_payout_methods(id),
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pilot_earnings ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_earnings_pilot ON public.pilot_earnings(pilot_id);
CREATE POLICY "pilot read own earnings" ON public.pilot_earnings FOR SELECT USING (auth.uid() = pilot_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin manage earnings" ON public.pilot_earnings FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));